# CONSEGNA per Claude Code — pagina ESSENCE v1
**Repo:** `~/Sites/kataclimb` · **Branch di lavoro:** `dev` (mai `main`) · **Data:** 19 settembre 2026

## Contesto
Marco tiene un intensivo ESSENCE il 10–11 ottobre 2026 (Syncrolink Ltd). Serve una pagina dedicata, **non pubblica**, con proposta completa, termini/liberatoria e due bottoni di pagamento. Il link lo manda Marco a mano su WhatsApp. Stesso schema di `inizia.html`: landing fuori dal menu.

## Cosa fare
Aggiungere nella **radice** del repo questi 6 file, così come sono (già completi e verificati):

| File | Cos'è |
|---|---|
| `essence.html` | pagina proposta + consensi + 2 bottoni |
| `essence-termini.html` | termini e liberatoria (è anche l'URL "Termini di servizio" dei Payment Link Stripe) |
| `essence-benvenuto.html` | pagina di arrivo dopo il pagamento |
| `essence-volo.jpg` · `essence-marco.jpg` · `essence-accademia.jpg` | immagini usate dalle pagine |

## Vincoli (non derogabili)
- **Nessuna scrittura DB, nessuna chiamata a Worker, nessuna modifica a file esistenti.** Solo i 6 file nuovi. Non toccare `index.html`, `portale.html`, `inizia*.html`, Worker.
- **Nessun link in ingresso**: le pagine NON vanno linkate da menu, footer, sitemap. Restano `noindex,nofollow`.
- Non modificare testi, prezzi, orari: sono validati da Marco. Se trovi un errore, segnalalo nella PR senza correggerlo.
- Terminologia del repo già rispettata: "Accademia" (mai "palestra"), mai "boulder", nomi corso completi ("Corso Open KataClimb").
- Testi ≥ 13px: verificato. JS verificato con `node --check`.

## Flusso
1. `git checkout dev && git pull`
2. Copia i 6 file nella radice.
3. Commit: `essence v1: pagina dedicata ESSENCE 10-11 ott (proposta, termini, benvenuto) — solo file nuovi, no DB`
4. **NON fare push senza conferma esplicita di Marco.**
5. Dopo il push su `dev`: anteprima su `https://kataclimb-dev.pages.dev/essence.html`. Marco controlla da telefono.
6. PR `dev → main` solo su richiesta di Marco. Nella descrizione: elenco dei 6 file, "nessun file esistente modificato", cosa guardare in anteprima (checkbox che attiva i bottoni; link ai termini; pagina benvenuto).

## Dopo il merge (lo fa Marco, poi un secondo mini-commit)
Quando Marco ha creato i due Payment Link su Stripe, vanno incollati in `essence.html`, in fondo al file:
```js
var LINK_FUORI_SEDE = '';   // ESSENCE 496 €
var LINK_ROMA       = '';   // ESSENCE + Corso Open KataClimb 696 €
```
Finché sono vuoti, i bottoni aprono una mail precompilata a marco@syncrolink.co: la pagina è usabile da subito.
In `essence-benvenuto.html` c'è `var LINK_GRUPPO_WA = '';` per il link del gruppo WhatsApp.

## Verifica live (la fa Claude dalla chat)
`curl -sI https://kataclimb.com/essence.html` → 200 · controllo `noindex` · controllo KC-BUILD `essence v1`.
